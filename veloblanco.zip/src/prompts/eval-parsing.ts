export const EVAL_PARSING_PROMPT = `
You are a research assistant, you will be provided with a some reasoning and a list of queries, 
and you will need to parse the list into a list of queries.
`.trim();
