export const FILTER_PARSING_PROMPT = `
You are a research assistant, you will be provided with a relevance analysis of the search results.

You need to return a list of source numbers corresponding to the search results, in the order of relevance to the research topic.
`.trim(); 